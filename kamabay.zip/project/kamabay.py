from KAMABAY.share.source.menu import *
#wtf_fucked
Banner2()
def main():
	print(Back.BLACK,Fore.CYAN + str("="*75))
	start = input(Keywords)
	if start in DataList:
		try:
			Banner1()
			os.system(keys_list +" "+DataList[start])
			timeout(1)
			Banner2()
			os.system('ls')
			main()
		except:
			restart()							
	elif start == "list" or start == "List":
		try:
			Banner1()
			list_packages()
			main()		
		except:		
			restart()
	elif start == keys_cln:
		try:
			Cleaning()
			clean()
			Banner1()
			main()
		except:
			restart()
	elif start == keys_pkgs:
		try:
			print(Back.BLACK,Fore.RED + str("="*75))
			Input_Key = input(keywords1)
			if Input_Key in DataList:
				try:
					os.system("w3m "+ " "+ DataList[Input_Key])
				except:
					restart()			
			elif Input_Key == "list" or Input_Key == "List":
				Banner1()
				list_packages()
				main()
			elif Input_Key == keys_h or Input_Key == keys_H:
				Banner1()
				print(Back.BLACK,Fore.GREEN,Style.BRIGHT + str(Helper))
				main()
			elif Input_Key == keys_cln:
				Cleaning()
				clean()
				Banner1()
				main()
			elif Input_Key == "Restart" or Input_Key == "restart":
				restart()
			elif Input_Key == keys_upug:
				Banner2()
				upug()
				os.system("clear && figlet -f KAMABAY/share/source/Style.flf ok | lolcat")
				timeout(3)
				Banner1()
				main()
			elif Input_Key == "apt update" or Input_Key == "apt upgrade":
				Error()
				timeout(3)
				Banner1()
			elif Input_Key == "configure" or Input_Key == "Configure":
				Banner2()
				configuration()
				os.system("clear && figlet -f KAMABAY/share/source/Style.flf ok | lolcat")
				timeout(2)
				Banner1()
				main()											
			elif Input_Key == Input_Key:
				Banner2()
				os.system(Input_Key)
				main()			
			else:
				restart()
		except:
			restart()					
	elif start == keys_h or start == keys_H:
		try:
			Banner1()
			print(Back.BLACK,Fore.GREEN,Style.BRIGHT + str(Helper))
			main()
		except:
			restart()
	elif start == keys_cls:
		try:
			Banner2()
			main()
		except:
			restart()
	elif start == shodan_atf:
		try:
			activation()
			main()
		except:
			restart()					
	elif start == keys_upug:
			try:
				Banner1()
				upug()
				os.system("clear && figlet -f KAMABAY/share/source/Style.flf ok | lolcat")
				timeout(2)
				Banner2()
				main()
			except:
				restart()								
	elif start == keys_Up or start == keys_Ug:
		try:
			Error()
			print(Fore.RED + "Please Using Commands 'up && ug' ")
			timeout(3)
			Banner1()
			main()
		except:
			restart()
	elif start == keys_U or start == keys_u:
		try:
			Banner1()
			Updates()
		except:
			restart()
	elif start == keys_S or start == keys_s:
		try:
			Banner1()
			print(Back.BLACK,Fore.GREEN,Style.BRIGHT + str(Helper))
			main()
		except:
			restart()		
	elif start == "exit":
		try:
			quits()
		except:
			restart()					
	elif start == "restart" or start == "Restart":
		  restart()
	elif start == start:
		try:
			Banner2()
			os.system(start)
			main()
		except:
			restart()	

if __name__ == '__main__':
	try:
		main()
	except:
		restart()	