import os
from time import sleep as timeout
from colorama import Fore,Back,Style
from KAMABAY.share.source.source_list1 import *

def clean():
	os.system("rm -rf KAMABAY/bin/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/bs4/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/bs4/builder/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/bs4/tests/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/certifi/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/chardet/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/chardet/cli/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/click/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/click_plugins/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/colorama/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/googlesearch/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/idna/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/cli/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/commands/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/distributions/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/index/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/models/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/network/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/operations/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/req/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/utils/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_internal/vcs/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_vendor/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_vendor/cachecontrol/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_vendor/cachecontrol/caches/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_vendor/certifi/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_vendor/chardet/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/pip/_vendor/chardet/cli/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/distlib/__pycache__")
	os.system("rm -rf KAMABAY/lib/python3.7/site-packages/distlib/_backport/__pycache__")
	os.system("rm -rf KAMABAY/share/source/README.md")
	os.system("rm -rf KAMABAY/share/source/__pycache__")
	os.system("rm -rf KAMABAY/share/source/update.zip")		
def upug(): 
	os.system("apt update -y && apt full-upgrade -y")	
def restart():
	os.system("clear && python3 kamabay.py")
def Banner1():
	os.system("clear")
	os.system("lolcat -f KAMABAY/share/source/banner0 | lolcat")
def Banner2():
	os.system("clear")
	os.system("lolcat -f KAMABAY/share/source/banner | lolcat")	
def Error():
	os.system("clear && figlet -f KAMABAY/share/source/Style.flf error | lolcat")
def Cleaning():
	os.system("clear && figlet -f KAMABAY/share/source/Style.flf clean | lolcat")	
	print("\033[1;36;40m Cleanning........")
	timeout(3)
	os.system("clear && figlet -f KAMABAY/share/source/Style.flf ok | lolcat")
	timeout(2)
def list_packages():
    for i, data in enumerate(DataList):
        print(Back.BLACK,Fore.CYAN,Style.BRIGHT + str(i)+":"+str(data))
        print("*"*50)
def activation():
	Banner2()
	os.system("shodan init gxqTOLnsEMM8DP1xA9rkqpNf7AYZc8bC")
	timeout(1)
	print(Back.BLACK,Fore.GREEN,Style.BRIGHT + str(info))
def quits():
		os.system("clear && figlet -f KAMABAY/share/source/Style.flf bye-bye | lolcat")
		print("\033[1;36;40m Support 'Kamabay' Subscribe Youtube\n Channel : https://www.youtube.com/channel/UCCkFPWbQaqonPc51uVeKvyg \n Facebook : https://fb.com/DracOS.V2")	        
def Updates():
	os.system("apt update -y &&  apt upgrade -y && apt install unzip -y")
	os.system("git clone https://github.com/ExsoKamabay/update.git")
	os.system("sudo unzip update/update.zip")
	os.system("sudo chmod +x update/*")
	os.system("sudo rm -rf KAMABAY/share/banner")
	os.system("sudo rm -rf KAMABAY/share/banner0")
	os.system("sudo rm -rf KAMABAY/share/source_list1.py")
	os.system("sudo rm -rf KAMABAY/share/Style.flf")
	os.system("sudo mv -f update/banner KAMABAY/share/source")
	os.system("sudo mv -f update/banner0 KAMABAY/share/source")
	os.system("sudo mv -f update/source_list1.py KAMABAY/share/source")
	os.system("sudo mv -f update/Style.flf KAMABAY/share/source")
	os.system("chmod +x KAMABAY/share/source/*")
	os.system("sudo rm -rf update")
	os.system("clear && figlet -f KAMABAY/share/source/Style.flf update... | lolcat")
	print(Fore.CYAN +"please wait while compiling file ...")	
	timeout(6)
	Banner2()
	print(Fore.CYAN,Back.BLACK + "the update process has finished, please run it again ^ _ ^")


Helper="""
list      : to see a list of package names that are ready to download,
            enter the package name on the keyboard to start downloading
help pkgs : Browse package names, to get information about package usage.
restart   : restart the program.
up && ug  : to update and upgrade the terminal. 
update    : download files and update files
clean     : clear out the remaining junk cache.
exit      : close program
  Usage: shodan [OPTIONS] COMMAND [ARGS]
  shodan alertto get info from the command 	
  alert       Manage the network alerts for your account
  convert     Convert the given input data file into a different format.
  count       Returns the number of results for a search
  data        Bulk data access to Shodan
  domain      View all available information for a domain
  download    Download search results and save them in a compressed JSON...
  honeyscore  Check whether the IP is a honeypot or not.
  host        View all available information for an IP address
  info        Shows general information about your account
  init        Initialize the Shodan command-line
  myip        Print your external IP address
  org         Manage your organization's access to Shodan
  parse       Extract information out of compressed JSON files.
  radar       Real-Time Map of some results as Shodan finds them.
  scan        Scan an IP/ netblock using Shodan.
  search      Search the Shodan database
  stats       Provide summary information about a search query
  stream      Stream data in real-time.

 NOTE : The rest use Terminal Commands ^_^
 V 0.1 BETTA
"""
info = """
Mail : nsissy_mansk@渡邊曜.我爱你
mail registration   : 20-March-2020
mail expires        : 76 Day
apikey registration : gxqTOLnsEMM8DP1xA9rkqpNf7AYZc8bC
"""
Keywords = "\033[1;36;40m <[__K_M_Y__]>"
keywords1 = "\033[1;36;40m <[__H_E_L_P__]>"
keys_list = "git clone"
keys_Up = "apt update"
keys_Ug = "apt upgrade"         
keys_h ="--help"
keys_H ="help"
keys_cls="clear"
keys_upug="up && ug"
keys_cln="clean"
keys_pkgs = "help pkgs"
keys_s = "shodan -h"
keys_S ="shodan --help"
shodan_atf = "shodan activate"
keys_u = "update"
keys_U = "Update"

